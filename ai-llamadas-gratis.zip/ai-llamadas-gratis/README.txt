# 🎯 AI Llamadas Gratis - Sistema 100% GRATIS

## ✨ Características

- 🧠 **Ollama** - IA completamente GRATIS
- 🔊 **Windows TTS** - Voz nativa de Windows GRATIS
- 📝 **Whisper** - Transcripción local GRATIS
- 📞 **Zadarma** - Llamadas (ya pagaste al paquete)
- 💰 **0€ costos adicionales** - Tuyo es GRATIS!

---

## 🚀 Instalación Rápida (Windows)

### Paso 1: Crear carpeta

```powershell
mkdir C:\ai-llamadas-gratis
cd C:\ai-llamadas-gratis
```

### Paso 2: Copiar archivos

Copia estos archivos a `C:\ai-llamadas-gratis\`:
- `package.json`
- `prompt.js`
- `ia.js`
- `voz.js`
- `index.js`
- `README.txt`

### Paso 3: Instalar dependencias

```powershell
npm install
```

### Paso 4: Iniciar Ollama

**Abre una nueva terminal y ejecuta:**

```powershell
ollama run mistral
```

**Deja esta ventana abierta!** ❌ No la cierres.

### Paso 5: Probar IA

**En la terminal original, ejecuta:**

```powershell
node index.js
```

---

## 💬 Probar Ahora

**Escribe algo como:**

```
Cliente: No me interesa ahora
Cliente: ¿Cuánto cuesta?
Cliente: Necesito pensarlo
```

**Lo que verás:**
1. ✅ IA genera respuesta
2. ✅ Windows habla (escucharás la voz)
3. ✅ Respuesta corta y profesional

---

## 📁 Archivos del Sistema

| Archivo | Propósito |
|---------|----------|
| `package.json` | Configuración del proyecto |
| `prompt.js` | Prompt base de la IA comercial |
| `ia.js` | Conexión con Ollama (IA) |
| `voz.js` | Windows TTS (conversión texto a voz) |
| `index.js` | Controlador principal |
| `README.txt` | Esta documentación |

---

## 🧠 Configuración Ollama

### Instalar Ollama (si no lo tienes)

1. **Descargar:** https://ollama.ai
2. **Instalar** en Windows
3. **Abrir terminal** y ejecutar:

```powershell
ollama run mistral
```

**Primer uso:** Descargará el modelo mistral (tarda unos minutos)

---

## 🔊 Windows TTS

**Ventajas:**
- ✅ GRATIS (ya viene con Windows)
- ✅ Voz natural en español
- ✅ Sin API keys
- ✅ 0€ costos

**Configuración:**
- Ya está configurado en `voz.js`
- Usa la voz por defecto de Windows
- Funciona automáticamente

---

## 📞 Lo que viene DESPUÉS

Cuando este sistema base funcione, te enseñaré:

### ✅ PASO 8 - Whisper Local
Instalar Whisper local para transcripción GRATIS

### ✅ PASO 9 - Conectar con Zadarma
Llamadas automáticas en tiempo real

### ✅ PASO 10 - Automatización completa
Sistema totalmente automático sin intervención

---

## 🧪 Pruebas

### Test 1: Responde a una objeción

```
Cliente: No tengo tiempo ahora
```

**Respuesta esperada:** Algo breve reafirmando valor.

### Test 2: Da precio

```
Cliente: ¿Cuánto cuesta el servicio?
```

**Respuesta esperada:** Oferta clara y directa.

### Test 3: Cierre

```
Cliente: Está bien, hazme el contrato
```

**Respuesta esperada:** Confirma y guía al siguiente paso.

---

## 🐛 Solución de problemas

### Error: "Ollama no responde"

**Solución:**
```powershell
# Verifica Ollama está corriendo
curl http://localhost:11434

# Si no responde:
ollama serve
# Luego en otra ventana:
ollama run mistral
```

### Error: "No escucho voz"

**Solución:**
- Verifica volumen de Windows
- Verifica speaker está conectado
- Prueba con PowerShell directo:

```powershell
PowerShell -Command "Add-Type –AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('Hola esto es una prueba');"
```

### Error: "Axios not installed"

**Solución:**
```powershell
npm install
```

---

## 📝 Notas Importantes

- ❌ NO necesitas API Keys de OpenAI
- ❌ NO necesitas credits de Whisper Cloud
- ❌ NO necesitas credits de TTS externos
- ✅ Ollama es 100% local y GRATIS
- ✅ Windows TTS es nativo y GRATIS
- ✅ Solo Zadarma (que ya pagaste al paquete)

---

## 🚀 Próximos Pasos

**Cuando esto funcione, te enseñaré:**

1. ✅ Whisper local para transcripción
2. ✅ Conectar con Zadarma via SIP
3. ✅ Llamadas automáticas en tiempo real
4. ✅ Sistema totalmente automatizado

---

## 📞 Soporte

**Enerlux Soluciones:**
- Email: enerlux.soluciones@gmail.com
- Tel: +34 610 243 061
- Zadarma: https://pbx.zadarma.com

---

**Versión:** 1.0 - Sistema Base
**Creado:** 2026-02-12
**Estado:** ✅ LISTO PARA PROBAR

---

## 🎉 ¡Empecemos!

1. Copia los archivos a tu PC
2. Instala dependencias: `npm install`
3. Inicia Ollama: `ollama run mistral`
4. Ejecuta: `node index.js`

**Escribe algo y verás la IA responder y hablar!** 🤖❄️