const axios = require("axios");
const promptBase = require("./prompt");

async function generarRespuesta(textoCliente) {
  try {
    const response = await axios.post("http://localhost:11434/api/generate", {
      model: "mistral",
      prompt: promptBase + "\nCliente: " + textoCliente + "\nAsesora:",
      stream: false
    });

    return response.data.response;
  } catch (error) {
    console.error("Error Ollama:", error.message);
    return "Lo siento, no pude generar respuesta en este momento.";
  }
}

module.exports = generarRespuesta;