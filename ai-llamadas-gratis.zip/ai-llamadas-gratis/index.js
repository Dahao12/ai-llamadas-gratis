const readline = require("readline");
const generarRespuesta = require("./ia");
const hablar = require("./voz");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function iniciar() {
  rl.question("Cliente: ", async (texto) => {
    const respuesta = await generarRespuesta(texto);

    console.log("IA:", respuesta);
    hablar(respuesta);

    iniciar();
  });
}

console.log("========================================");
console.log("  SISTEMA IA COMERCIAL - 100% GRATIS");
console.log("========================================");
console.log("");
console.log("Requisitos:");
console.log("- Ollama corriendo: ollama run mistral");
console.log("- Windows TTS activo");
console.log("");
console.log("Escribe lo que diría el cliente");
console.log("La IA responderá y hablará por voz");
console.log("");
console.log("Escribe 'exit' para salir");
console.log("");
console.log("----------------------------------------");
console.log("");

iniciar();