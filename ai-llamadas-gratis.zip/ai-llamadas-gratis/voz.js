const { exec } = require("child_process");

function hablar(texto) {
  const comando = `PowerShell -Command "Add-Type –AssemblyName System.Speech; $speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; $speak.Speak('${texto}');"`;

  exec(comando, (error) => {
    if (error) {
      console.error("Error TTS:", error);
    }
  });
}

module.exports = hablar;